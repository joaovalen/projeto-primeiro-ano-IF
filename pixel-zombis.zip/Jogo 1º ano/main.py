import pygame as pg
import sys
import json
import time
from os import path
from configs import *
from sprites import *
from tilemap import *


# Hud functions
def desenha_vida_player(surf, x, y, porcent):
	if porcent < 0:
		porcent = 0
	TAMANHO_BARRA = 100
	ALTURA_BARRA = 20
	prenchimento = porcent * TAMANHO_BARRA
	retang_exterior = pg.Rect(x, y, TAMANHO_BARRA, ALTURA_BARRA)
	retang_prencher = pg.Rect(x, y, prenchimento, ALTURA_BARRA)
	if porcent > 0.6:
		col = VERDE
	elif porcent > 0.3:
		col = AMARELO
	else:
		col = VERMELHO
	# Desenhando 
	pg.draw.rect(surf, col, retang_prencher)
	pg.draw.rect(surf, BRANCO, retang_exterior, 2)

class Game:
	
	def __init__(self):
		# Primeira a ser rodada

		# Configurando o som
		# O último item é o buffer, memória principal
		# 
		pg.mixer.pre_init(44100, -16, 1, 2048)
		# Inicializando o pygame e criando a janela
		pg.init()
		self.screen = pg.display.set_mode((LARGURA_TELA , ALTURA_TELA))
		pg.display.set_caption(TITULO)
		# Clock cuida da velocidade (fps)
		self.clock = pg.time.Clock()
		# Carrega imagens e arquivos
		self.load_data()
		# Começa a rodar
		self.running = True


	# Função para escrever na tela
	def draw_text(self, text, font_name, size, color, x, y, align="nw"):
		font = pg.font.Font(font_name, size)
		text_surface = font.render(text, True, color)
		text_rect = text_surface.get_rect()
		if align == "nw":
			text_rect.topleft = (x, y)
		if align == "ne":
			text_rect.topright = (x, y)
		if align == "sw":
			text_rect.bottomleft = (x, y)
		if align == "se":
			text_rect.bottomright = (x, y)
		if align == "n":
			text_rect.midtop = (x, y)
		if align == "s":
			text_rect.midbottom = (x, y)
		if align == "e":
			text_rect.midright = (x, y)
		if align == "w":
			text_rect.midleft = (x, y)
		if align == "center":
			text_rect.center = (x, y)
		self.screen.blit(text_surface, text_rect)

	def load_data(self):
		# Comandos facilitados para encontrar o que for necessário
		self.game_folder = path.dirname(__file__)
		# Pasta mapas
		self.map_folder = path.join(self.game_folder, 'maps')
		# Pasta imagens
		self.img_folder = path.join(self.game_folder, 'img')
		# Pasta com os sons
		snd_folder = path.join(self.game_folder, 'snd')
		# Pasta com as musicas
		music_folder = path.join(self.game_folder, 'music')
		# Pasta com as fontes
		fonts_folder = path.join(self.game_folder, 'fonts')
		# Fonte para o texto
		self.title_font = path.join(fonts_folder, 'ZOMBIE.TTF')
		# Display pra outras coisas
		self.hud_font = path.join(self.img_folder, 'Impacted2.0.TTF')
		# Menu
		self.menufundo = path.join(self.img_folder, 'menu.JPEG')
		# Tela para cobrir a tela enquanto pausado
		self.dim_screen = pg.Surface(self.screen.get_size()).convert_alpha()
		self.dim_screen.fill((0, 0, 0, 180))
		# map recebe o __init__ da classe TiledMap
		# Encontra as imagens para os objetos
		
		self.bullet_images = {}
		self.bullet_images['large'] = pg.image.load(path.join(self.img_folder, BULLET_IMG)).convert_alpha()
		self.bullet_images['small'] = pg.transform.scale(self.bullet_images['large'], (10,10))
		self.mob_img = pg.image.load(path.join(self.img_folder, MOB_IMG)).convert_alpha()
		self.mob_img = pg.transform.scale(self.mob_img, (29, 37))
		self.splat = pg.image.load(path.join(self.img_folder, SPLAT)).convert_alpha()
		self.splat = pg.transform.scale(self.splat, (64, 64))
		# Lista com as imagens para os Flashes do cano
		self.gun_flashes = []
		for img in FLASHES_CANO:
			self.gun_flashes.append(pg.image.load(path.join(self.img_folder, img)).convert_alpha())
		
		# Items
		self.item_images = {}
		for item in ITEM_IMAGES:
			self.item_images[item] = pg.image.load(path.join(self.img_folder, ITEM_IMAGES[item])).convert_alpha()
		
		# Efeito de luz
		self.fog = pg.Surface((LARGURA_TELA, ALTURA_TELA))
		# Prencher a tela com uma cor mais escura
		self.fog.fill(NIGHT_COLOR)
		# Carregando e adaptando a luz ao redor do player
		self.light_mask = pg.image.load(path.join(self.img_folder, LIGHT_MASK)).convert_alpha()
		self.light_mask = pg.transform.scale(self.light_mask, LIGHT_RADIUS)
		self.light_rect = self.light_mask.get_rect()

		# Dicionário com os efeitos sonoros
		self.effects_sounds = {}
		for type in EFFECTS_SOUNDS:
			# Variável temporária para alterar volume
			a = pg.mixer.Sound(path.join(snd_folder, EFFECTS_SOUNDS[type]))
			# Mudando volume, atualmente é 1 e pode ir até 0 
			a.set_volume(0.1)
			self.effects_sounds[type] = a
		
		# Dicionário com diferentes tipos de sons para as armas
		self.weapon_sounds = {}
		for weapon in WEAPON_SOUNDS:
			self.weapon_sounds[weapon] = []
			for snd in WEAPON_SOUNDS[weapon]:
				s = pg.mixer.Sound(path.join(snd_folder, snd))
				s.set_volume(0.01)
				self.weapon_sounds[weapon].append(s)
			
		
		# Dicionário com os sons dos zumbis
		self.zombie_moan_sounds = []
		for snd in ZOMBIE_MOAN_SOUNDS:
			c = pg.mixer.Sound(path.join(snd_folder, snd))
			c.set_volume(0.2)
			self.zombie_moan_sounds.append(c)

		# Player tomando dano
		self.player_hit_sounds = []
		for snd in PLAYER_HIT_SOUNDS:
			d = pg.mixer.Sound(path.join(snd_folder, snd))
			d.set_volume(0.4)
			self.player_hit_sounds.append(d)		
		
		# Zumbi morrendo
		self.zombie_hit_sounds = []
		for snd in ZOMBIE_HIT_SOUNDS:
			e = pg.mixer.Sound(path.join(snd_folder, snd))
			e.set_volume(0.5)
			self.zombie_hit_sounds.append(e)		
	
		# Carregando o som de fundo
		pg.mixer.music.load(path.join(music_folder, BG_MUSIC))
		#bg.set_volume(0.5)

	def new(self):
		# Começa um novo jogo
	
		# Todas as sprites são adicionadas ao um grupo contendo todas
		# Também são adicionadas a um grupo da sua classe
		# LayeredUpdates funciona como um grupo, porém tem propriedades adicionais
		# Você pode dar uma propriedade de camada, e ele desenhará em ordem
		self.all_sprites = pg.sprite.LayeredUpdates()
		self.walls = pg.sprite.Group()
		self.mobs = pg.sprite.Group()
		self.bullets = pg.sprite.Group()
		self.items = pg.sprite.Group()
		# Player
		self.player_img = pg.image.load(path.join(self.img_folder, PLAYER_IMG)).convert_alpha()
		self.player_img = pg.transform.scale(self.player_img, (43, 37))
		# Mapa
		self.map = TiledMap(path.join(self.map_folder, 'fase1.tmx'))
		# Chama a função make_map dentro do TiledMap, que executa as funções necesárias
		self.map_img = self.map.make_map()
		self.map_rect = self.map_img.get_rect()
		# Gerando colisão com os objetos do mapa
		for tile_object in self.map.tmxdata.objects:
			# Encontra o centro do objeto, para um melhor posicionamento no mapa
			obj_center = vec(tile_object.x + tile_object.width / 2,
							 tile_object.y + tile_object.height / 2)
			# Checa nome do quadrado
			if tile_object.name == 'player':
				self.player = Player(self, obj_center.x, obj_center.y)
			if tile_object.name == 'wall':
				Obstacle(self, tile_object.x, tile_object.y, tile_object.width, tile_object.height)
			if tile_object.name == 'zombie':
				Mob(self, obj_center.x, obj_center.y)
			if tile_object.name in ['health', 'shotgun']:
				Item(self, obj_center, tile_object.name)
		
		# Contador de zumbis mortos
		self.kills = 0  	
		# Pause
		self.paused = False
		# Camera
		self.camera = Camera(self.map.width, self.map.height)
		# Efeitos sonoros quando começamos novo nível
		self.effects_sounds['level_start'].play()
		# Efeito luz
		self.night = False

	def run(self):
		# Loop do jogo

		self.playing = True

		pg.mixer.music.play(loops =- 1)

		while self.playing:
			# Checa a velocidade
			self.dt = self.clock.tick(FPS) / 1000
			# Checa por eventos
			self.events()
			# Se não estiver pausado:
			if not self.paused:
				# Faz atualizações
				self.update()
			# Recria a janela
			self.draw()

	def events(self):
		# Loop do jogo - eventos

		for event in pg.event.get():
			if event.type == pg.QUIT:
				self.quit()
			if event.type == pg.KEYDOWN:
				if event.key == pg.K_ESCAPE:
					self.quit()
				# Caso pressionado inverte o valor de paused
				# Se estava False, agora se torna True
				if event.key == pg.K_p:
					self.paused = not self.paused
				if event.key == pg.K_n:
					self.night = not self.night

	def update(self):
		# Aqui são checadas as colisões entre as sprites
		# Também são executados os updates que acontecem no código das sprites
		
		# Atualizar os objetos
		self.all_sprites.update()
		# Podemos mandar a camera seguir qualquer coisa simplesmente mudando o argumento
		self.camera.update(self.player)
		
		# Player passando em items
		hits = pg.sprite.spritecollide(self.player, self.items, False)
		for hit in hits:
			if hit.type == 'health' and self.player.health < PLAYER_HEALTH:
				hit.kill()
				# Efeito sonoro
				self.effects_sounds['health_up'].play()
				# Dando vida para o player
				self.player.add_health(HEALTH_PACK_AMOUNT)
			if hit.type == 'shotgun':
				hit.kill()
				self.effects_sounds['gun_pickup'].play()
				self.player.weapon = 'shotgun'

				game_folder = path.dirname(__file__)	
				img_folder = path.join(game_folder, 'img')
				PLAYER_IMG = 'manBlue_machine.png'
				self.player_img = pg.image.load(path.join(img_folder, PLAYER_IMG)).convert_alpha()
				self.player_img = pg.transform.scale(self.player_img, (43, 37))

		# Mobs colidindo com player
		hits = pg.sprite.spritecollide(self.player, self.mobs, False, collide_hit_rect)
		for hit in hits:
			# Efeito sonoro
			if random() < 0.5:
				choice(self.player_hit_sounds).play()
			# Tira vida do player
			self.player.health -= DANO_MOB
			hit.vel = vec(0, 0)
			if self.player.health <= 0:
				self.playing = False
		# Empurrão e cor do dano
		if hits:
			self.player.hit()
			self.player.pos += vec(EMPURRAO_MOB, 0).rotate(-hits[0].rot)

		# Colisão balas e zumbis
		hits = pg.sprite.groupcollide(self.mobs, self.bullets, False, True)
		for hit in hits:
			# Tirando vida e desacelerando
			# hits é um dicionário, cada chave é um mob atingido
			# o valor é uma lista de balas que o atingiram
			# Nesse for passamos por cada mob e subtraímos o dano de cada bala
			# pela quantidade de balas
			hit.health -= WEAPONS[self.player.weapon]['damage'] * len(hits[hit])
			hit.vel = vec(0, 0)
			self.kills += 1
	
	def render_fog():
		# Desenhar a imagem da luz no fog
		self.fog.fill(NIGHT_COLOR)
		self.light_rect.center = self.camera.apply(self.player).center
		self.fog.blit(self.light_mask, self.light_rect)
		# Blend é o que faz o efeito de transparência 
		self.screen.blit(self.fog, (0, 0), special_flags=pg.BLEND_MULT)

	def draw(self):
		# Loop do jogo - desenhar
		pg.display.set_caption("{:.2f}".format(self.clock.get_fps()))
		#self.screen.fill(COR_FUNDO)
		self.screen.blit(self.map_img, self.camera.apply_rect(self.map_rect))
		# Self.draw_grid()
		for sprite in self.all_sprites:
			# Se a sprite é um mob, desenha a vida
			if isinstance(sprite, Mob):
				sprite.desenha_vida()
			self.screen.blit(sprite.image, self.camera.apply(sprite))
			# Desenha os retângulos de hit box se chamado
		
		# Iluminação 
		if self.night:
			self.render_fog()

		# HUD funtions
		desenha_vida_player(self.screen, 10, 10, self.player.health / PLAYER_HEALTH)
		# Mostrando a quantidade de zumbis
		#self.draw_text('Zombies: {}'.format(len(self.mobs)), self.hud_font, 30, BRANCO, LARGURA_TELA - 10, 10, align="ne")
		# Depois de desenhar tudo, flip the display (Double buffering)
		if self.paused:
			self.screen.blit(self.dim_screen, (0, 0))
			self.draw_text("Paused", self.title_font, 185, VERMELHO, LARGURA_TELA / 2, ALTURA_TELA / 2, align="center")
		
		pg.display.flip()
	
	def quit(self):
		pg.quit()
		sys.exit()

	def mostra_tela_inicial(self):
		pass
	
	def show_go_screen(self):
		screen.fill(BLACK)
		self.draw_text("GAME OVER", self.title_font, 100, VERMELHO,
					   LARGURA_TELA / 2, ALTURA_TELA / 2, align="center")
		self.draw_text("Press a key to start", self.title_font, 75, BRANCO,
					   LARGURA_TELA / 2, ALTURA_TELA * 3 / 4, align="center")


# Chama a classe game, primeira coisa a acontecer no código
g = Game()
g.mostra_tela_inicial()
while g.running:
	# Começe um jogo novo
	g.new()
	# Roda
	g.run()
	# Mostrar tela de Game over
	g.mostra_tela_go()





pg.quit