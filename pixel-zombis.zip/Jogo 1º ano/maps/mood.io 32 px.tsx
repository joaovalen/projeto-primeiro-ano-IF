<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="mood.io 32 px" tilewidth="32" tileheight="32" tilecount="2160" columns="54">
 <image source="../img/tilesheet_complete.png" width="1728" height="1280"/>
 <terraintypes>
  <terrain name="Novo Terreno" tile="929"/>
 </terraintypes>
 <tile id="768" terrain="0,0,0,0"/>
 <tile id="769" terrain="0,0,0,0"/>
 <tile id="822" terrain="0,0,0,0"/>
 <tile id="823" terrain="0,0,0,0"/>
</tileset>
