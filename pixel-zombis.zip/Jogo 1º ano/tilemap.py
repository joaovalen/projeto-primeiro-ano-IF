import pygame as pg
from configs import *
import pytmx

# Faz com que o comando spritecollide use os retÂngulos de colisão, não de desenho
def collide_hit_rect(one, two):
	return one.hit_rect.colliderect(two.rect)

class TiledMap:
	def __init__(self, filename):
		tm = pytmx.load_pygame(filename, pixelalpha = True)
		# Tamanho do mapa
		self.width = tm.width * tm.tilewidth
		self.height = tm.height * tm.tileheight
		# Guarda informações
		self.tmxdata = tm

	def render(self, surface):
		# Comando para encontrar a imagem correspondente ao quadrado
		ti = self.tmxdata.get_tile_image_by_gid
		# Percorre as camadas
		for layer in self.tmxdata.visible_layers:
			if isinstance(layer, pytmx.TiledTileLayer):
				for x, y, gid, in layer:
					tile = ti(gid)
					# Checa se é um quadrado e desenha
					if tile:
						surface.blit(tile, (x * self.tmxdata.tilewidth, y * self.tmxdata.tileheight))

	def make_map(self):
		# Cria superfície temporária para desenhar o mapa
		temp_surface = pg.Surface((self.width, self.height))
		self.render(temp_surface)
		return temp_surface



class Camera:
	# Tem noção do tamanho do mapa e conforme o jogador se move
	# Faz as alterações necessárias na posição do mapa
	def __init__(self, largura_mapa, altura_mapa):
		# Camera usa retângulo para seguir o player
		self.camera = pg.Rect(0, 0, largura_mapa, altura_mapa)
		self.largura_mapa = largura_mapa
		self.altura_mapa = altura_mapa

		 
	def apply(self, entidade):
		return entidade.rect.move(self.camera.topleft)

	def apply_rect(self, rect):
		return rect.move(self.camera.topleft)

	def update(self, alvo):
		# Camera se baseia no centro do player
		x = -alvo.rect.centerx + int(LARGURA_TELA / 2)
		y = -alvo.rect.centery + int(ALTURA_TELA / 2)
		

		# Limite da camera
		x = min(0, x) # Esquerda
		y = min(0, y) # Topo
		x = max(-(self.largura_mapa - LARGURA_TELA), x) # Direita
		y = max(-(self.altura_mapa - ALTURA_TELA), y) # Fundo
		self.camera = pg.Rect(x,y, self.largura_mapa, self.altura_mapa)
		
		

