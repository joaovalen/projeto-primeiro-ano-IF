import pygame as pg
vec = pg.math.Vector2
# Configurações e cia

# Definindo cores (R, G, B)
BRANCO = (255, 255, 255)
PRETO = (0, 0, 0)
CINZA_ESCURO = (40, 40, 40)
CINZA_CLARO = (100, 100, 100)
VERDE = (0, 255, 0)
VERMELHO = (255, 0, 0)
AMARELO = (255, 255, 0)
MARROM = (106, 55, 5)
CIANO = (0, 255, 255)

# Configurações
LARGURA_TELA = 1024   # 16 * 64 or 32 * 32 or 64 * 16
ALTURA_TELA = 600  # 16 * 48 or 32 * 24 or 64 * 12
FPS = 60
TITULO = "My game"
COR_FUNDO = MARROM

TAMANHO_QUADRADOS = 64
LARGURA_GRADE = LARGURA_TELA / TAMANHO_QUADRADOS
ALTURA_GRADE = ALTURA_TELA / TAMANHO_QUADRADOS


# Configurações do jogador
PLAYER_HEALTH = 100
VELOCIDADE_JOGADOR = 250
# Velocidade de rotação
PLAYER_ROT_SPEED = 250
PLAYER_IMG = 'manBlue_gun.png'
# Retângulo de contato do player
PLAYER_HIT_RECT = pg.Rect(0, 0, 35, 35)
CANO_ARMA = vec(30, 10)


# Configuração armas
BULLET_IMG = 'bullet.png'
WEAPONS = {}
WEAPONS['pistol'] = {'bullet_speed': 650,
					 'bullet_lifetime': 1000,
					 'rate': 250,
				     'kickback': 200,
				     'spread': 2,
				     'damage': 10,
				     'bullet_size': 'large',
				     'bullet_count': 1}

WEAPONS['shotgun'] = {'bullet_speed': 400,
					  'bullet_lifetime': 500,
					  'rate': 900,
				      'kickback': 450,
				      'spread': 20,
				      'damage': 5,
				      'bullet_size': 'small',
				      'bullet_count': 12}




# Configurações Mobs
MOB_IMG = 'zombie1_hold.png'
VELOCIDADE_MOB = [200, 175, 175, 150]
MOB_HIT_RECT = pg.Rect(0 , 0, 30, 30)
MOB_HEALTH = 100
DANO_MOB = 10
EMPURRAO_MOB = 20
# Área de detecção
DETECT_RADIUS = 400
# Círculo ao redor do mob no qual ele evita outros mobs
AREA_EVITAR = 50

# Efeitos
FLASHES_CANO = ['whitePuff15.png', 'whitePuff16.png', 'whitePuff17.png', 'whitePuff18.png']
DURACAO_FLASH = 40
TAMANHO_FLASH = 30
TAMANHO_FLASH2 = 40
SPLAT = 'splat green.png'
# Criando lista com diversos números que usaremos para gerar cores rgb
DAMAGE_ALPHA = [i for i in range(0, 255, 25)]
NIGHT_COLOR = (20, 20, 20)
LIGHT_RADIUS = (500, 500)
LIGHT_MASK = "light_350_med.png"

# Layers
WALL_LAYER = 1
PLAYER_LAYER = 2
BULLET_LAYER = 3
MOB_LAYER = 2
EFFECTS_LAYER = 4
ITEMS_LAYER = 1 


# Items
ITEM_IMAGES = {'health': 'health_pack.png',
			   'shotgun': 'obj_shotgun.png'}
HEALTH_PACK_AMOUNT = 30
# Flutuação do item
BOB_RANGE = 20
BOB_SPEED = 0.3

# Sounds
BG_MUSIC = 'espionage.ogg'
PLAYER_HIT_SOUNDS = ['pain/8.wav', 'pain/9.wav', 'pain/10.wav', 'pain/11.wav']
ZOMBIE_MOAN_SOUNDS = ['brains2.wav', 'brains3.wav', 'zombie-roar-1.wav', 'zombie-roar-2.wav',
						'zombie-roar-3.wav', 'zombie-roar-5.wav', 'zombie-roar-6.wav', 'zombie-roar-7.wav']
ZOMBIE_HIT_SOUNDS = ['splat-15.wav']
WEAPON_SOUNDS = {'pistol': ['pistol.wav'],
				 'shotgun': ['shotgun.wav']}
EFFECTS_SOUNDS = {'level_start': 'level_start.wav',
				  'health_up': 'health_pack.wav',
				  'gun_pickup': 'gun_pickup.wav'}

# fonte
font_size = 30