
class Botao1(pygame.sprite.Sprite):

	def __init__(self):
		pygame.sprite.Sprite.__init__(self):
		self.img_folder = path.join(self.game_folder, 'img')
		self.image = path.join(self.img_folder, 'botaojogar.png')

class Botao2(pygame.sprite.Sprite):

	def __init__(self):
		pygame.sprite.Sprite.__init__(self):
		self.img_folder = path.join(self.game_folder, 'img')
		self.image = path.join(self.img_folder, 'botaopontuacao.png')

class Botao3(pygame.sprite.Sprite):

	def __init__(self):
		pygame.sprite.Sprite.__init__(self):
		self.img_folder = path.join(self.game_folder, 'img')
		self.image = path.join(self.img_folder, 'botaosair.png')

class Menu(pygame.sprite.Sprite):

	def __init__(self, screen)