import pygame as pg
from random import uniform, choice, randint, random
from configs import *
from tilemap import collide_hit_rect
import pytweening as tween
from itertools import chain
vec = pg.math.Vector2

# Função de colisão que pode ser usada por qualque objeto
# Simplesmente passando o objeto, o grupo com o qual ele irá
# Colidir, e a direção (x,y)
def colisao_com_paredes(sprite, group, dir):
        # Fazendo player deslizar na parede caso andando diagonalmente em sua direção
        if dir == 'x':
            hits = pg.sprite.spritecollide(sprite, sprite.game.walls, False, collide_hit_rect)
            if hits:
                # Checa se o centro das paredes é maior que o centro do player
                if hits[0].rect.centerx > sprite.hit_rect.centerx:
                    sprite.pos.x = hits[0].rect.left - sprite.hit_rect.width / 2
                if hits[0].rect.centerx < sprite.hit_rect.centerx:
                    sprite.pos.x = hits[0].rect.right + sprite.hit_rect.width / 2
                sprite.vel.x = 0
                sprite.hit_rect.centerx = sprite.pos.x
        if dir == 'y':
            hits = pg.sprite.spritecollide(sprite, group, False, collide_hit_rect)
            if hits:
                if hits[0].rect.centery > sprite.hit_rect.centery:
                    sprite.pos.y = hits[0].rect.top - sprite.hit_rect.height / 2
                if hits[0].rect.centery < sprite.hit_rect.centery:
                    sprite.pos.y = hits[0].rect.bottom + sprite.hit_rect.width / 2
                sprite.vel.y = 0
                sprite.hit_rect.centery = sprite.pos.y


class Player(pg.sprite.Sprite):
    #Primeira função a ser executada
    def __init__(self, game, x, y):
        # Checa a camada do player
        self._layer = PLAYER_LAYER
        # Adiciona o player ao grupo com todas as sprites
        self.groups = game.all_sprites
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.player_img
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.hit_rect = PLAYER_HIT_RECT
        self.hit_rect.center = self.rect.center
        self.vel = vec(0,0)
        self.pos = vec(x, y) 
        # Rastrea a rotação
        self.rot = 0
        # Bullet
        self.last_shot = 0
        # Vida
        self.health = PLAYER_HEALTH
        # Arma no momento
        self.weapon = 'pistol'
        self.damaged = False


    def get_keys(self):
        self.rot_speed = 0
        self.vel = vec(0, 0)
        keys = pg.key.get_pressed()
        if keys[pg.K_a]:
            self.rot_speed = PLAYER_ROT_SPEED
        if keys[pg.K_d]:
            self.rot_speed = -PLAYER_ROT_SPEED
        if keys[pg.K_w]:
            self.vel = vec(VELOCIDADE_JOGADOR, 0).rotate(-self.rot)
        if keys[pg.K_s]:
            self.vel = vec(-VELOCIDADE_JOGADOR / 2, 0).rotate(-self.rot)
        if keys[pg.K_SPACE]:
            self.shoot()

    def shoot(self):
        now = pg.time.get_ticks()
        if now - self.last_shot > WEAPONS[self.weapon]['rate']:
            self.last_shot = now
            dir = vec(1, 0).rotate(-self.rot)
            # Fazendo com que a bala saia um pouco mais do lado da imagem, no cano
            pos = self.pos + CANO_ARMA.rotate(-self.rot)
            # Coice
            self.vel = vec(-WEAPONS[self.weapon]['kickback'], 0).rotate(-self.rot)
            # Quantidade de balas
            for i in range(WEAPONS[self.weapon]['bullet_count']):
                # Dispersão
                spread = uniform(-WEAPONS[self.weapon]['spread'], WEAPONS[self.weapon]['spread'])
                Bullet(self.game, pos, dir.rotate(spread))
                # Efeito sonoro, loop para cortar sons já em execução e começar os novos
                snd = choice(self.game.weapon_sounds[self.weapon])
                if snd.get_num_channels() > 2:
                    snd.stop()
                snd.play()
            # Flash da arma
            FlashArma(self.game, pos)
          
           
        
           

    def update(self):
        self.get_keys()
        self.rot = (self.rot + self.rot_speed * self.game.dt) % 360
        self.image = pg.transform.rotate(self.game.player_img, self.rot)
        # Efeito visual dano
        if self.damaged:
            try:
                self.image.fill((255, 255, 255, next(self.damage_alpha)), special_flags = pg.BLEND_RGBA_MULT)
            except:
                self.damaged = False
      
        self.rect = self.image.get_rect()
        self.rect.center = self.pos
        self.pos += self.vel * self.game.dt
        # Testa colisão com paredes usando o retângulo de contato
        self.hit_rect.centerx = self.pos.x
        colisao_com_paredes(self, self.game.walls, 'x')
        self.hit_rect.centery = self.pos.y
        colisao_com_paredes(self, self.game.walls, 'y')
        self.rect.center = self.hit_rect.center

    def hit(self):
        # Caso atingido começa uma corrente nos números guardados
        # Os quais geram cores rgb
        # Como é uma corrente, vai até um tom mais forte
        # e começa de novo
        self.damaged = True
        self.damage_alpha = chain(DAMAGE_ALPHA * 2)

    def add_health(self, amount):
        self.health += amount
        if self.health > PLAYER_HEALTH:
            self.health = PLAYER_HEALTH

class Mob(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self._layer = MOB_LAYER
        self.groups = game.all_sprites, game.mobs
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.mob_img.copy()
        # Determinando retângulo de colisão
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.hit_rect = MOB_HIT_RECT.copy()
        self.hit_rect.center = self.rect.center
        
        self.pos = vec(x, y) 
        # Velocidade
        self.vel = vec(0, 0)
        # Rotação mais natural
        self.acc = vec(0, 0)
        self.rect.center = self.pos
        self.rot = 0
        self.health = MOB_HEALTH
        # Escolhe uma velocidade aleatoriamente 
        self.speed = choice(VELOCIDADE_MOB)
        # Alvo
        self.target = game.player


    def avoid_mobs(self):
        # Percorre todos os mobs
        for mob in self.game.mobs:
            if mob != self:
                # Encontra distância entre os mobs
                dist = self.pos - mob.pos
                # Se a distância for entre 0 e a área determinada, desviar
                if 0 < dist.length() < AREA_EVITAR:
                    self.acc += dist.normalize()

    def update(self):
        # Distância do alvo
        target_dist = self.target.pos -self.pos
        # Target_dist é vetor então precisa de lenght
        if target_dist.length_squared() < DETECT_RADIUS**2:
            # Efeitos sonoros precisam ser 'raros'
            # como iremos executar isso a cada frame
            # precisamos de um número bem pequeno para o random
            if random() < 0.001:
                # Escolhe som aleatoriamente e toca
                choice(self.game.zombie_moan_sounds).play()
            # Olhar para o player
            self.rot = target_dist.angle_to(vec(1,0))
            self.image = pg.transform.rotate(self.game.mob_img, self.rot)
            self.rect = self.image.get_rect()
            self.rect.center = self.pos
            # Movimentar em direção ao player
            self.acc = vec(1, 0).rotate(-self.rot)
            # Evitar contato com outros mobs
            self.avoid_mobs()
            self.acc.scale_to_length(self.speed)
            # Dando atrito ao movimento
            self.acc += self.vel * -1
            self.vel += self.acc * self.game.dt
            self.pos += self.vel * self.game.dt + 0.5 * self.acc * self.game.dt ** 2
            # Checa por colisão
            self.hit_rect.centerx = self.pos.x
            colisao_com_paredes(self, self.game.walls, 'x')
            self.hit_rect.centery = self.pos.y
            colisao_com_paredes(self, self.game.walls, 'y')
            self.rect.center = self.hit_rect.center
        # Checando vida
        if self.health <= 0:
            # Efeito sonoro
            choice(self.game.zombie_hit_sounds).play()
            self.kill()
            # Desenhando restos, gosma
            self.game.map_img.blit(self.game.splat, self.pos - vec(32, 32))

    def desenha_vida(self):
        if self.health > 60:
            col = VERDE
        elif self.health > 30:
            col = AMARELO
        else:
            col = VERMELHO
        # Desenhando a barra de vida
        width = int(self.rect.width * self.health / MOB_HEALTH)
        self.barra_health = pg.Rect(0, 0, width, 7)
        if self.health < MOB_HEALTH:
            pg.draw.rect(self.image, col, self.barra_health)


class Bullet(pg.sprite.Sprite):
    def __init__(self, game, pos, dir):
        self._layer = BULLET_LAYER
        self.groups = game.all_sprites, game.bullets
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.bullet_images[WEAPONS[game.player.weapon]['bullet_size']]
        self.rect = self.image.get_rect()
        self.pos = vec(pos)
        self.rect.center = pos 
        # Precisão aleatória
        self.vel = dir * WEAPONS[game.player.weapon]['bullet_speed'] * uniform(0.9, 1.1)
        self.spawn_time = pg.time.get_ticks()

    def update(self):
        self.pos += self.vel * self.game.dt
        self.rect.center = self.pos
        # Checa colisão 
        if pg.sprite.spritecollideany(self, self.game.walls):
            self.kill()
        # Se tempo de vida acabou, some
        if pg.time.get_ticks() - self.spawn_time > WEAPONS[self.game.player.weapon]['bullet_lifetime']:
            self.kill()


class Wall(pg.sprite.Sprite):
    def __init__(self, game, x, y):
        self._layer = WALL_LAYER
        self.groups = game.all_sprites, game.walls
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.wall_img
        self.rect = self.image.get_rect()
        self.x = x
        self.y = y
        self.rect.x = x * TAMANHO_QUADRADOS
        self.rect.y = y * TAMANHO_QUADRADOS


class Obstacle(pg.sprite.Sprite):
    def __init__(self, game, x, y, w, h):
        self.groups = game.walls
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        # Posição x,y altura e largura
        self.rect = pg.Rect(x, y, w, h)
        self.x = x
        self.y = y
        self.rect.x = x 
        self.rect.y = y 


class FlashArma(pg.sprite.Sprite):
    def __init__(self, game, pos):
        self._layer = EFFECTS_LAYER
        self.groups = game.all_sprites
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        # Tamanho aleatório
        size = randint(TAMANHO_FLASH, TAMANHO_FLASH2)
        # Deixa a imagem do tamanho selecionado pelo randint
        self.image = pg.transform.scale(choice(game.gun_flashes), (size, size))
        # Encontra retangulo da imagem 
        self.rect = self.image.get_rect()
        # Coloca o centro do retângulo na posição atual
        self.pos = pos
        self.rect.center = pos
        # Desaparecer com a imagem se passou o tempo de vida
        self.spawn_time = pg.time.get_ticks()

    def update(self):
        # Checa se acabou o tempo de vida
        if pg.time.get_ticks() - self.spawn_time > DURACAO_FLASH:
            self.kill()
        
class Item(pg.sprite.Sprite):
    def __init__(self, game, pos, type):
        self.groups = game.all_sprites, game.items
        pg.sprite.Sprite.__init__(self, self.groups)
        self.game = game
        self.image = game.item_images[type]
        self.rect = self.image.get_rect()
        self.type = type 
        self.pos = pos
        self.rect.center = pos 
        # Definindo a função do pytweening que vamos usar
        self.tween = tween.easeInOutSine
        # Rastreia a posição em que estamos
        self.step = 0
        # Direção
        self.dir = 1

    def update(self):
        
        # Easing function, movimentos mais suaves
        # Bobbing
        # Quanto longe da posição inicial?
        offset = BOB_RANGE * (self.tween(self.step / BOB_RANGE) - 0.5)
        # Movimentando
        self.rect.centery = self.pos.y + offset * self.dir
        self.step += BOB_SPEED
        # Limite da curva
        if self.step > BOB_RANGE:
            self.step = 0
            self.dir *= -1